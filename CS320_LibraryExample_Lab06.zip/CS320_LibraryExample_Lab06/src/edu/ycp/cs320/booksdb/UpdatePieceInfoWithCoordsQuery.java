package edu.ycp.cs320.booksdb;


import java.util.Scanner;

import edu.ycp.cs320.booksdb.persist.DatabaseProvider;
import edu.ycp.cs320.booksdb.persist.IDatabase;
import edu.ycp.cs320.booksdb.model.Pair;

public class UpdatePieceInfoWithCoordsQuery {
	public static void main(String[] args) throws Exception {
		Scanner keyboard = new Scanner(System.in);

		// Create the default IDatabase instance
		InitDatabase.init(keyboard);
		
		System.out.print("Enter Original X: ");
		String oldXS = keyboard.nextLine();
		System.out.print("Enter Original Y: ");
		String oldYS = keyboard.nextLine();
		System.out.print("Enter New X: ");
		String newXS = keyboard.nextLine();
		System.out.print("Enter New Y: ");
		String newYS = keyboard.nextLine();
		System.out.println("Enter state of capture: ");
		String capString = keyboard.nextLine();
		
		int oldX = Integer.parseInt(oldXS);
		int oldY = Integer.parseInt(oldYS);
		int newX = Integer.parseInt(newXS);
		int newY = Integer.parseInt(newYS);
		boolean capture;
		if (capString == "true") {
			capture = true;
		}
		else capture = false;
		
		// get the DB instance and execute the transaction
		IDatabase db = DatabaseProvider.getInstance();
		Pair<Integer, Integer> pair = db.updatePieceInfoByCoords(oldX, oldY, newX, newY, capture);
		System.out.println("Piece info updated. new Coordinates: " + pair.getLeft() + ", " + pair.getRight());
	}
}