package edu.ycp.cs320.booksdb;

import java.util.List;
import java.util.Scanner;

import edu.ycp.cs320.booksdb.model.User;
import edu.ycp.cs320.booksdb.model.Piece;
import edu.ycp.cs320.booksdb.persist.DatabaseProvider;
import edu.ycp.cs320.booksdb.persist.IDatabase;

public class FindPieceByXY {
	public static void main(String[] args) throws Exception {
		Scanner keyboard = new Scanner(System.in);

		// Create the default IDatabase instance
		InitDatabase.init(keyboard);
		
		System.out.print("Enter X Coordinate: ");
		String xString = keyboard.nextLine();
		
		System.out.print("Enter Y Coordinate: ");
		String yString = keyboard.nextLine();
		
		int x = Integer.parseInt(xString);
		int y = Integer.parseInt(yString);
		
		// get the DB instance and execute transaction
		IDatabase db = DatabaseProvider.getInstance();
		List<Piece> pieceList = db.findPieceByXY(x, y);

		// check if anything was returned and output the list
		if (pieceList.isEmpty()) {
			System.out.println("No available pieces at that location");
		}
		else {
			for (Piece piece : pieceList) {
				System.out.print(piece.getColor() + ", " + piece.getGameId() + ", X:" + piece.getPosX() + ", Y:" + piece.getPosY() + ", ");
				System.out.println(piece.getHasMoved() + ", " + piece.getType() + ", " + piece.getCaptured());
			}
		}
	}
}