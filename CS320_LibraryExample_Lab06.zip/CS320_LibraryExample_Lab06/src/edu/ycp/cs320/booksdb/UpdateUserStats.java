package edu.ycp.cs320.booksdb;


import java.util.Scanner;

import edu.ycp.cs320.booksdb.persist.DatabaseProvider;
import edu.ycp.cs320.booksdb.persist.IDatabase;

public class UpdateUserStats {
	public static void main(String[] args) throws Exception {
		Scanner keyboard = new Scanner(System.in);

		// Create the default IDatabase instance
		InitDatabase.init(keyboard);
		
		System.out.print("Enter username: ");
		String username = keyboard.nextLine();
		
		System.out.print("Enter New Win Total: ");
		String win = keyboard.nextLine();
		int newWin = Integer.parseInt(win);
		
		System.out.print("Enter New Lose Total: ");
		String lose = keyboard.nextLine();
		int newLose = Integer.parseInt(lose);
		
		// get the DB instance and execute the transaction
		IDatabase db = DatabaseProvider.getInstance();
		Integer user_id = db.updateStatsByUser(username, newWin, newLose);
		if (user_id != -1) {
		System.out.println("Stats updated for user_id "+ user_id);
		} else System.out.println("Update failed");
	}
}
