package edu.ycp.cs320.booksdb.model;

public class User {
	private int userId;
	private String password;
	private String username;
	private int rank, wins, losses;
	
	public User() {
		
	}
	
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public int getUserId() {
		return userId;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getUsername() {
		return username;
	}
	
	public void setRank(int rank) {
		this.rank = rank;
	}
	
	public int getRank() {
		return rank;
	}
	
	public void setWins(int win) {
		this.wins = win;
	}
	
	public int getWins() {
		return wins;
	}
	
	public void setLosses(int lose) {
		this.losses = lose;
	}
	
	public int getLosses() {
		return losses;
	}
}
