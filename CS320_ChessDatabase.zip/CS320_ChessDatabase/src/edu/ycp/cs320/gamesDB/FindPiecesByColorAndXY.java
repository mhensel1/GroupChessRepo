package edu.ycp.cs320.gamesDB;

import java.util.List;
import java.util.Scanner;

import edu.ycp.cs320.gamesDB.model.Piece;
import edu.ycp.cs320.gamesDB.model.User;
import edu.ycp.cs320.gamesDB.persist.DatabaseProvider;
import edu.ycp.cs320.gamesDB.persist.IDatabase;

public class FindPiecesByColorAndXY {
	public static void main(String[] args) throws Exception {
		Scanner keyboard = new Scanner(System.in);

		// Create the default IDatabase instance
		InitDatabase.init(keyboard);
		
		System.out.print("Enter X Coordinate: ");
		String xString = keyboard.nextLine();
		
		System.out.print("Enter Y Coordinate: ");
		String yString = keyboard.nextLine();
		
		System.out.println("Enter Color: ");
		String colorStr = keyboard.nextLine();
		boolean color = true;
		System.out.println("Enter game_id: ");
		String idString = keyboard.nextLine();		
		int id = Integer.parseInt(idString);
		
		if (colorStr.equals("black")) {
			color = false;
		}
		
		int x = Integer.parseInt(xString);
		int y = Integer.parseInt(yString);

		
		// get the DB instance and execute transaction
		IDatabase db = DatabaseProvider.getInstance();
		List<Piece> pieceList = db.findPieceByColorAndXY(color, x, y, id);

		// check if anything was returned and output the list
		if (pieceList.isEmpty()) {
			System.out.println("No available pieces of that color and coordinate");
		}
		else {
			for (Piece piece : pieceList) {
				System.out.print("Piece Color: " + piece.getColor() + "| Game ID: " + piece.getGameId() + "| Xposition: " + piece.getPosX() + "| Yposition: " + piece.getPosY() + "| Hasmoved: ");
				System.out.println(piece.getHasMoved() + "| Type: " + piece.getType() + "| Captured: " + piece.getCaptured());
			}
		}
	}
}