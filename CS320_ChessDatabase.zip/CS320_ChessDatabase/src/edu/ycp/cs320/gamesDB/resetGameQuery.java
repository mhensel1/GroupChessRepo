package edu.ycp.cs320.gamesDB;


import java.util.Scanner;

import edu.ycp.cs320.gamesDB.persist.DatabaseProvider;
import edu.ycp.cs320.gamesDB.persist.IDatabase;

public class resetGameQuery {
	public static void main(String[] args) throws Exception {
		Scanner keyboard = new Scanner(System.in);

		// Create the default IDatabase instance
		InitDatabase.init(keyboard);
		
		System.out.print("Enter game id: ");
		String gameString = keyboard.nextLine();
		int game_id = Integer.parseInt(gameString);

		
		// get the DB instance and execute the transaction
		IDatabase db = DatabaseProvider.getInstance();
		Integer id = db.resetGame(game_id);
		if (id != -1) {
		System.out.println("games table updated at id: "+ id);
		} else System.out.println("Update failed");
	}
}
