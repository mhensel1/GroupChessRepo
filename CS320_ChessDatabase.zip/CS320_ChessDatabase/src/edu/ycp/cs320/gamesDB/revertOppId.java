package edu.ycp.cs320.gamesDB;


import java.util.Scanner;

import edu.ycp.cs320.gamesDB.persist.DatabaseProvider;
import edu.ycp.cs320.gamesDB.persist.IDatabase;

public class revertOppId {
	public static void main(String[] args) throws Exception {
		Scanner keyboard = new Scanner(System.in);

		// Create the default IDatabase instance
		InitDatabase.init(keyboard);
		
		System.out.print("Enter game id: ");
		String gameString = keyboard.nextLine();
		int game_id = Integer.parseInt(gameString);
		
		
		// get the DB instance and execute the transaction
		IDatabase db = DatabaseProvider.getInstance();
		Integer user_id = db.revertOppId(game_id);
		if (user_id != -1) {
		System.out.println("Opp id for " + game_id + " reverted to "+ user_id);
		} else System.out.println("Update failed");
	}
}
