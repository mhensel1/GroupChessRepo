package edu.ycp.cs320.gamesDB;


import java.util.Scanner;

import edu.ycp.cs320.gamesDB.persist.DatabaseProvider;
import edu.ycp.cs320.gamesDB.persist.IDatabase;

public class UpdateOppID {
	public static void main(String[] args) throws Exception {
		Scanner keyboard = new Scanner(System.in);

		// Create the default IDatabase instance
		InitDatabase.init(keyboard);
		
		System.out.print("Enter game id: ");
		String gameString = keyboard.nextLine();
		int game_id = Integer.parseInt(gameString);
		
		System.out.print("Enter opp id: ");
		String win = keyboard.nextLine();
		int player_id = Integer.parseInt(win);
		
		// get the DB instance and execute the transaction
		IDatabase db = DatabaseProvider.getInstance();
		Integer user_id = db.updateOppID(game_id, player_id);
		if (user_id != -1) {
		System.out.println("games table updated with id: "+ user_id);
		} else System.out.println("Update failed");
	}
}
