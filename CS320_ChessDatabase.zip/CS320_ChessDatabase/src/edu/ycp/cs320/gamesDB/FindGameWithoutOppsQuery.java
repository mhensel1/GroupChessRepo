package edu.ycp.cs320.gamesDB;

import java.util.List;
import java.util.Scanner;

import edu.ycp.cs320.gamesDB.model.Game;
import edu.ycp.cs320.gamesDB.model.Pair;
import edu.ycp.cs320.gamesDB.model.User;
import edu.ycp.cs320.gamesDB.persist.DatabaseProvider;
import edu.ycp.cs320.gamesDB.persist.IDatabase;

public class FindGameWithoutOppsQuery {
	public static void main(String[] args) throws Exception {
		
		Scanner keyboard = new Scanner(System.in);

		// Create the default IDatabase instance
		InitDatabase.init(keyboard);
		
		IDatabase db = DatabaseProvider.getInstance();
		List<Game> gamesList = db.findGamesWithoutOpps();
		if (gamesList.isEmpty()) {
			System.out.println("No games found in need of opponents");
		}
		else {
			for (Game game : gamesList) {
				System.out.println("Game Id: " + game.getGameId() + " | Turns: " + game.getTurns() + "| GameOver: " + game.getGameOver());
			}			
		}

	}
}