package edu.ycp.cs320.gamesDB;

import java.util.List;
import java.util.Scanner;

import edu.ycp.cs320.gamesDB.model.User;
import edu.ycp.cs320.gamesDB.persist.DatabaseProvider;
import edu.ycp.cs320.gamesDB.persist.IDatabase;

public class FindUserWithNameAndPassQuery {
	public static void main(String[] args) throws Exception {
		Scanner keyboard = new Scanner(System.in);

		// Create the default IDatabase instance
		InitDatabase.init(keyboard);
		
		System.out.print("Enter username: ");
		String username = keyboard.nextLine();
		
		System.out.print("Enter Password: ");
		String password = keyboard.nextLine();
		
		// get the DB instance and execute transaction
		IDatabase db = DatabaseProvider.getInstance();
		List<User> userList = db.findUserByUserByNameAndPass(username, password);
		
		// check if anything was returned and output the list
		if (userList.isEmpty()) {
			System.out.println("Username and password do not match to a user");
		}
		else {
			for (User user : userList) {
				System.out.println(user.getUsername() + ", " + user.getPassword() + ", " + user.getRank() + ", " + user.getWins() + ", " + user.getLosses());
			}
		}
	}
}
