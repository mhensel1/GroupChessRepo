package edu.ycp.cs320.gamesDB;

import java.util.List;
import java.util.Scanner;

import edu.ycp.cs320.gamesDB.model.User;
import edu.ycp.cs320.gamesDB.persist.DatabaseProvider;
import edu.ycp.cs320.gamesDB.persist.IDatabase;

public class FindUserWithNameQuery {
	public static void main(String[] args) throws Exception {
		Scanner keyboard = new Scanner(System.in);

		// Create the default IDatabase instance
		InitDatabase.init(keyboard);
		
		System.out.print("Enter username: ");
		String username = keyboard.nextLine();
		
		// get the DB instance and execute transaction
		IDatabase db = DatabaseProvider.getInstance();
		List<User> userList = db.findUserbyUsername(username);
		
		// check if anything was returned and output the list
		if (userList.isEmpty()) {
			System.out.println("Username does not match a user");
		}
		else {
			for (User user : userList) {
				System.out.println(user.getUsername() + ", " + user.getPassword() + ", " + user.getRank() + ", " + user.getWins() + ", " + user.getLosses());
			}
		}
	}
}
