package edu.ycp.cs320.gamesDB;

import java.util.List;
import java.util.Scanner;

import edu.ycp.cs320.gamesDB.model.Piece;
import edu.ycp.cs320.gamesDB.model.User;
import edu.ycp.cs320.gamesDB.persist.DatabaseProvider;
import edu.ycp.cs320.gamesDB.persist.IDatabase;

public class FindAllPiecesByColorQuery {
	public static void main(String[] args) throws Exception {
		Scanner keyboard = new Scanner(System.in);

		// Create the default IDatabase instance
		InitDatabase.init(keyboard);
		
		System.out.print("Enter a Color: ");
		String colorString = keyboard.nextLine();
		boolean color = true;
		if (colorString.equals("white")) {
			color = true;
		}
		else if (colorString.equals("black")) {
			color = false;
		}
		System.out.println("Enter game_id: ");
		String idString = keyboard.nextLine();		
		int id = Integer.parseInt(idString);
		// get the DB instance and execute transaction
		IDatabase db = DatabaseProvider.getInstance();
		List<Piece> pieceList = db.findAllPiecesByColor(color, id);

		// check if anything was returned and output the list
		if (pieceList.isEmpty()) {
			System.out.println("No available " + colorString + " pieces");
		}
		else {
			for (Piece piece : pieceList) {
				System.out.print(piece.getColor() + ", " + piece.getGameId() + ", X:" + piece.getPosX() + ", Y:" + piece.getPosY() + ", ");
				System.out.println(piece.getHasMoved() + ", " + piece.getType() + ", " + piece.getCaptured());
			}
		}
	}
}
