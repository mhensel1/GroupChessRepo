package edu.ycp.cs320.gamesDB;

import java.util.List;
import java.util.Scanner;

import edu.ycp.cs320.gamesDB.model.Piece;
import edu.ycp.cs320.gamesDB.model.User;
import edu.ycp.cs320.gamesDB.persist.DatabaseProvider;
import edu.ycp.cs320.gamesDB.persist.IDatabase;

public class FindPiecesByGameIDQuery {
	public static void main(String[] args) throws Exception {
		Scanner keyboard = new Scanner(System.in);

		// Create the default IDatabase instance
		InitDatabase.init(keyboard);
		
		System.out.print("Enter Game ID: ");
		String idString = keyboard.nextLine();
		
		
		int id = Integer.parseInt(idString);
		
		// get the DB instance and execute transaction
		IDatabase db = DatabaseProvider.getInstance();
		List<Piece> pieceList = db.findPiecesByGameID(id);

		// check if anything was returned and output the list
		if (pieceList.isEmpty()) {
			System.out.println("No available pieces for that game id");
		}
		else {
			for (Piece piece : pieceList) {
				System.out.print("Piece Color: " + piece.getColor() + "| Game ID: " + piece.getGameId() + "| Xposition: " + piece.getPosX() + "| Yposition: " + piece.getPosY() + "| Hasmoved: ");
				System.out.println(piece.getHasMoved() + "| Type: " + piece.getType() + "| Captured: " + piece.getCaptured());
			}
		}
	}
}