package edu.ycp.cs320.gamesDB.persist;

import java.util.List;

import edu.ycp.cs320.gamesDB.model.Game;
import edu.ycp.cs320.gamesDB.model.Pair;
import edu.ycp.cs320.gamesDB.model.Piece;
import edu.ycp.cs320.gamesDB.model.User;

public interface IDatabase {
	public List<Pair<User, Game>> findUserAndGameByID(int id);
	public List<Pair<User, Game>> findUserAndGameByUserName(String username);
	public Integer insertNewUserIntoUserTable(String username, String password);
	public List<Pair<User, Game>> findAllGamesWithUsers();
	public List<User> findAllUsers();
	public List<User> removeBookByTitle(String title);
	public Integer updateStatsByUser(String username, int newWin, int newLose);
	public List<User> findUserByUserByNameAndPass(String username, String password);
	public List<User> findUserbyUsername(String username);
	public List<Piece> findPieceByXY(int xCor, int yCor);
	public List<Piece> findPiecesByPieceName(String piece_name);
	public Pair<Integer, Integer> updatePieceInfoByCoords(int oldX, int oldY, int newX, int newY, boolean capture, boolean hasMoved);
	public List<Piece> findAllPiecesByColor(boolean color);
}
