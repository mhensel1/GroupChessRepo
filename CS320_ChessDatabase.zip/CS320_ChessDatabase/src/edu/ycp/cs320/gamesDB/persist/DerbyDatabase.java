package edu.ycp.cs320.gamesDB.persist;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import edu.ycp.cs320.gamesDB.model.Game;
import edu.ycp.cs320.gamesDB.model.Pair;
import edu.ycp.cs320.gamesDB.model.Piece;
import edu.ycp.cs320.gamesDB.model.User;
import edu.ycp.cs320.gamesDB.model.gameUser;

public class DerbyDatabase implements IDatabase {
	static {
		try {
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		} catch (Exception e) {
			throw new IllegalStateException("Could not load Derby driver");
		}
	}
	
	private interface Transaction<ResultType> {
		public ResultType execute(Connection conn) throws SQLException;
	}

	private static final int MAX_ATTEMPTS = 10;

	@Override
	public List<Piece> findAllPiecesByColor(boolean color) {
		return executeTransaction(new Transaction<List<Piece>>() {
			@Override
			public List<Piece> execute(Connection conn) throws SQLException {
				PreparedStatement stmt = null;
				ResultSet resultSet = null;
				
				try {
					stmt = conn.prepareStatement(
							"select * from pieces " +
									"where color = ?"
					);
					
					List<Piece> result = new ArrayList<Piece>();
					
					stmt.setBoolean(1, color);
					
					resultSet = stmt.executeQuery();
					
					// for testing that a result was returned
					Boolean found = false;
					
					while (resultSet.next()) {
						found = true;
						
						Piece piece = new Piece();
						loadPiece(piece, resultSet, 1);
						
						result.add(piece);
					}
					
					// check if any users were found
					if (!found) {
						if (color == true) {
							System.out.println("No available white pieces");
						} else System.out.println("No available black pieces");
						
					}
					
					return result;
				} finally {
					DBUtil.closeQuietly(resultSet);
					DBUtil.closeQuietly(stmt);
				}
			}
		});
	}
	
	@Override
	public List<Piece> findPieceByXY(int xCor, int yCor) {
		return executeTransaction(new Transaction<List<Piece>>() {
			@Override
			public List<Piece> execute(Connection conn) throws SQLException {
				PreparedStatement stmt = null;
				ResultSet resultSet = null;
				
				try {
					stmt = conn.prepareStatement(
							"select * from pieces " +
									"where PosX = ? and PosY = ?"
					);
					
					List<Piece> result = new ArrayList<Piece>();
					
					stmt.setInt(1, xCor);
					stmt.setInt(2,  yCor);
					
					resultSet = stmt.executeQuery();
					
					// for testing that a result was returned
					Boolean found = false;
					
					while (resultSet.next()) {
						found = true;
						
						Piece piece = new Piece();
						loadPiece(piece, resultSet, 1);
						
						result.add(piece);
					}
					
					// check if any users were found
					if (!found) {
						System.out.println("No avaiable piece at that location");
					}
					
					return result;
				} finally {
					DBUtil.closeQuietly(resultSet);
					DBUtil.closeQuietly(stmt);
				}
			}
		});
	}
	
	@Override
	public Pair<Integer, Integer> updatePieceInfoByCoords(int oldX, int oldY, int newX, int newY, boolean capture, boolean hasMoved) {
		return executeTransaction(new Transaction<Pair<Integer, Integer>>() {
			@Override
			public Pair<Integer, Integer> execute(Connection conn) throws SQLException {
				PreparedStatement stmt1 = null;
				PreparedStatement stmt2 = null;	
				PreparedStatement stmt3 = null;	
				
				ResultSet resultSet1 = null;
				ResultSet resultSet3 = null;
				Pair<Integer, Integer> pair = null;

				// try to retrieve user_id (if it exists) from DB, for User's info passed into query
				try {
						stmt3 = conn.prepareStatement(
								"select * from pieces " +
									"where PosX = ? and PosY = ?"
								);
						stmt3.setInt(1, oldX);
						stmt3.setInt(2, oldY);
						resultSet1 = stmt3.executeQuery();
						if (!resultSet1.next()) {
							System.out.println("No available piece at that location");
						}
						else {
							stmt1 = conn.prepareStatement(
									"update pieces " +
											"set PosX = ?, PosY = ?, captured = ?, hasMoved = ?" +
											"where PosX = ? and PosY = ?"
									);
							stmt1.setInt(1, newX);
							stmt1.setInt(2, newY);
							stmt1.setBoolean(3, capture);
							stmt1.setBoolean(4, hasMoved);
							stmt1.setInt(5,  oldX);
							stmt1.setInt(6, oldY);
						
							// execute the query, get the result
							stmt1.executeUpdate();
							
							if (oldX != newX && oldY != newY) {
								stmt2 = conn.prepareStatement(
											"update pieces " +
													"set hasMoved = ?" +
													"where PosX = ? and PosY = ?"
										);
								stmt2.setBoolean(1, true);
								stmt2.setInt(2, newX);
								stmt2.setInt(3,  newY);
								
								stmt2.executeUpdate();
								System.out.println("hasMoved updated");
							}
							
							System.out.println("Piece originally at (" + oldX + oldY + ") updated");
							pair = new Pair<Integer, Integer>(newX, newY);
						}
					
				} finally {
					DBUtil.closeQuietly(resultSet1);
					DBUtil.closeQuietly(stmt1);
					DBUtil.closeQuietly(stmt2);					
					DBUtil.closeQuietly(resultSet3);
					DBUtil.closeQuietly(stmt3);
				}
				return pair;
			}
		});
	}
	
	@Override
	public List<Piece> findPiecesByPieceName(String piece_name) {
		return executeTransaction(new Transaction<List<Piece>>() {
			@Override
			public List<Piece> execute(Connection conn) throws SQLException {
				PreparedStatement stmt = null;
				ResultSet resultSet = null;
				
				try {
					stmt = conn.prepareStatement(
							"select * from pieces " +
									"where type = ?"
					);
					
					List<Piece> result = new ArrayList<Piece>();
					
					stmt.setString(1, piece_name);
					
					resultSet = stmt.executeQuery();
					
					// for testing that a result was returned
					Boolean found = false;
					
					while (resultSet.next()) {
						found = true;
						
						Piece piece = new Piece();
						loadPiece(piece, resultSet, 1);
						
						result.add(piece);
					}
					
					// check if any users were found
					if (!found) {
						System.out.println("No available pieces with that name found");
					}
					
					return result;
				} finally {
					DBUtil.closeQuietly(resultSet);
					DBUtil.closeQuietly(stmt);
				}
			}
		});
	}
	
	// transaction that retrieves a Game, and its User by Title
	@Override
	public List<Pair<User, Game>> findUserAndGameByID(final int id) {
		return executeTransaction(new Transaction<List<Pair<User,Game>>>() {
			@Override
			public List<Pair<User, Game>> execute(Connection conn) throws SQLException {
				PreparedStatement stmt = null;
				ResultSet resultSet = null;
				
				try {
					stmt = conn.prepareStatement(
							"select users.*, games.* " +
							"  from  users, games, gameUsers " +
							"  where games.game_id = ? " +
							"    and users.user_id = gameUsers.user_id " +
							"    and games.game_id = gameUsers.game_id"
					);
					stmt.setInt(1, id);
					
					List<Pair<User, Game>> result = new ArrayList<Pair<User,Game>>();
					
					resultSet = stmt.executeQuery();
					
					// for testing that a result was returned
					Boolean found = false;
					
					while (resultSet.next()) {
						found = true;
						
						User user = new User();
						loadUser(user, resultSet, 1);
						Game game = new Game();
						loadGame(game, resultSet, 4);
						
						result.add(new Pair<User, Game>(user, game));
					}
					
					// check if the title was found
					if (!found) {
						System.out.println("<" + id + "> was not found in the games table");
					}
					
					return result;
				} finally {
					DBUtil.closeQuietly(resultSet);
					DBUtil.closeQuietly(stmt);
				}
			}
		});
	}
	
	
	// transaction that retrieves a list of Books with their Authors, given User's last name
	@Override
	public List<Pair<User, Game>> findUserAndGameByUserName(final String username) {
		return executeTransaction(new Transaction<List<Pair<User,Game>>>() {
			@Override
			public List<Pair<User, Game>> execute(Connection conn) throws SQLException {
				PreparedStatement stmt = null;
				ResultSet resultSet = null;

				// try to retrieve Authors and Books based on User's last name, passed into query
				try {
					stmt = conn.prepareStatement(
							"select users.*, games.* " +
									"  from  users, games, gameUsers " +
									"  where users.username = ? " +
									"    and users.user_id = gameUsers.user_id " +
									"    and games.game_id = gameUsers.game_id"
							);
					stmt.setString(1, username);
					
					// establish the list of (User, Game) Pairs to receive the result
					List<Pair<User, Game>> result = new ArrayList<Pair<User,Game>>();
					
					// execute the query, get the results, and assemble them in an ArrayLsit
					resultSet = stmt.executeQuery();
					while (resultSet.next()) {
						User user = new User();
						loadUser(user, resultSet, 1);
						Game game = new Game();
						loadGame(game, resultSet, 7);
						
						result.add(new Pair<User, Game>(user, game));
					}
					
					return result;
				} finally {
					DBUtil.closeQuietly(resultSet);
					DBUtil.closeQuietly(stmt);
				}
			}
		});
	}
	
	
	// transaction that retrieves all Books in Library, with their respective Authors
		@Override
		public List<Pair<User, Game>> findAllGamesWithUsers() {
			return executeTransaction(new Transaction<List<Pair<User,Game>>>() {
				@Override
				public List<Pair<User, Game>> execute(Connection conn) throws SQLException {
					PreparedStatement stmt = null;
					ResultSet resultSet = null;
					
					try {
						stmt = conn.prepareStatement(
								"select users.*, games.* " +
								"  from users, games, gameUsers " +
								"  where users.user_id = gameUsers.user_id " +
								"    and games.game_id     = gameUsers.game_id "
						);
						
						List<Pair<User, Game>> result = new ArrayList<Pair<User,Game>>();
						
						resultSet = stmt.executeQuery();
						
						// for testing that a result was returned
						Boolean found = false;
						
						while (resultSet.next()) {
							found = true;
							
							User user = new User();
							loadUser(user, resultSet, 1);
							Game game = new Game();
							loadGame(game, resultSet, 7);
							
							result.add(new Pair<User, Game>(user, game));
						}
						
						// check if any games were found
						if (!found) {
							System.out.println("No games were found in the database");
						}
						
						return result;
					} finally {
						DBUtil.closeQuietly(resultSet);
						DBUtil.closeQuietly(stmt);
					}
				}
			});
		}	
	
	
	// transaction that retrieves all Authors in Library
	@Override
	public List<User> findAllUsers() {
		return executeTransaction(new Transaction<List<User>>() {
			@Override
			public List<User> execute(Connection conn) throws SQLException {
				PreparedStatement stmt = null;
				ResultSet resultSet = null;
				
				try {
					stmt = conn.prepareStatement(
							"select * from users "
					);
					
					List<User> result = new ArrayList<User>();
					
					resultSet = stmt.executeQuery();
					
					// for testing that a result was returned
					Boolean found = false;
					
					while (resultSet.next()) {
						found = true;
						
						User user = new User();
						loadUser(user, resultSet, 1);
						
						result.add(user);
					}
					
					// check if any users were found
					if (!found) {
						System.out.println("No users were found in the database");
					}
					
					return result;
				} finally {
					DBUtil.closeQuietly(resultSet);
					DBUtil.closeQuietly(stmt);
				}
			}
		});
	}
	
	
	// transaction that inserts new Game into the Books table
	// also first inserts new User into Authors table, if necessary
	// and then inserts entry into BookAuthors junction table
	@Override
	public Integer insertNewUserIntoUserTable(final String username, final String password) {
		return executeTransaction(new Transaction<Integer>() {
			@Override
			public Integer execute(Connection conn) throws SQLException {
				PreparedStatement stmt1 = null;
				PreparedStatement stmt2 = null;
				PreparedStatement stmt3 = null;
				PreparedStatement stmt4 = null;
				PreparedStatement stmt5 = null;
				PreparedStatement stmt6 = null;				
				
				ResultSet resultSet1 = null;
				ResultSet resultSet3 = null;
				ResultSet resultSet5 = null;				
				
				// for saving author ID and book ID
				Integer user_id = -1;

				// try to retrieve user_id (if it exists) from DB, for User's info passed into query
				try {
					stmt1 = conn.prepareStatement(
							"select user_id from users " +
							"  where username = ? and password = ? "
					);
					stmt1.setString(1, username);
					stmt1.setString(2, password);
					
					// execute the query, get the result
					resultSet1 = stmt1.executeQuery();

					
					// if User was found then save author_id					
					if (resultSet1.next())
					{
						user_id = resultSet1.getInt(1);
						System.out.println("User <" + username + ", " + password + "> found with ID: " + user_id);						
					}
					else
					{
						System.out.println("User <" + username + ", " + password + "> not found");
				
						// if the User is new, insert new User into Authors table
						if (user_id <= 0) {
							// prepare SQL insert statement to add User to Authors table
							stmt2 = conn.prepareStatement(
									"insert into users (password, username, rank, wins, losses) " +
									"  values(?, ?, ?, ?, ?) "
							);
							stmt2.setString(1, password);
							stmt2.setString(2, username);
							stmt2.setInt(3, 0);
							stmt2.setInt(4, 0);
							stmt2.setInt(5, 0);
							
							// execute the update
							stmt2.executeUpdate();
							
							System.out.println("New User <" + username + ", " + password + "> inserted in Users table");						
						
							
						}
						
						// execute the query, get the result
						resultSet3 = stmt1.executeQuery();

						
						// if User was found then save author_id					
						if (resultSet3.next())
						{
							user_id = resultSet3.getInt(1);
							System.out.println("User <" + username + ", " + password + "> User ID: " + user_id);						
						}
						
					}
					return user_id;
					
				} finally {
					DBUtil.closeQuietly(resultSet1);
					DBUtil.closeQuietly(stmt1);
					DBUtil.closeQuietly(stmt2);					
					DBUtil.closeQuietly(resultSet3);
					DBUtil.closeQuietly(stmt3);					
					DBUtil.closeQuietly(stmt4);
					DBUtil.closeQuietly(resultSet5);
					DBUtil.closeQuietly(stmt5);
					DBUtil.closeQuietly(stmt6);
				}
			}
		});
	}
	
	
	// transaction that deletes Game (and possibly its User) from Library
	@Override
	public List<User> removeBookByTitle(final String title) {
		return executeTransaction(new Transaction<List<User>>() {
			@Override
			public List<User> execute(Connection conn) throws SQLException {
				PreparedStatement stmt1 = null;
				PreparedStatement stmt2 = null;
				PreparedStatement stmt3 = null;
				PreparedStatement stmt4 = null;
				PreparedStatement stmt5 = null;
				PreparedStatement stmt6 = null;							
				
				ResultSet resultSet1    = null;			
				ResultSet resultSet2    = null;
				ResultSet resultSet5    = null;
				
				try {
					// first get the User(s) of the Game to be deleted
					// just in case it's the only Game by this User
					// in which case, we should also remove the User(s)
					stmt1 = conn.prepareStatement(
							"select users.* " +
							"  from  users, games, bookAuthors " +
							"  where games.title = ? " +
							"    and users.author_id = bookAuthors.author_id " +
							"    and games.book_id     = bookAuthors.book_id"
					);
					
					// get the Game's User(s)
					stmt1.setString(1, title);
					resultSet1 = stmt1.executeQuery();
					
					// assemble list of Authors from query
					List<User> users = new ArrayList<User>();					
				
					while (resultSet1.next()) {
						User user = new User();
						loadUser(user, resultSet1, 1);
						users.add(user);
					}
					
					// check if any Authors were found
					// this shouldn't be necessary, there should not be a Game in the DB without an User
					if (users.size() == 0) {
						System.out.println("No author was found for title <" + title + "> in the database");
					}
										
					// now get the Game(s) to be deleted
					// we will need the book_id to remove associated entries in BookAuthors (junction table)
				
					stmt2 = conn.prepareStatement(
							"select games.* " +
							"  from  games " +
							"  where games.title = ? "
					);
					
					// get the Game(s)
					stmt2.setString(1, title);
					resultSet2 = stmt2.executeQuery();
					
					// assemble list of Books from query
					List<Game> games = new ArrayList<Game>();					
				
					while (resultSet2.next()) {
						Game game = new Game();
						loadGame(game, resultSet2, 1);
						games.add(game);
					}
					
					// first delete entries in BookAuthors junction table
					// can't delete entries in Books or Authors tables while they have foreign keys in junction table
					// prepare to delete the junction table entries (bookAuthors)
					stmt3 = conn.prepareStatement(
							"delete from bookAuthors " +
							"  where book_id = ? "
					);
					
					// delete the junction table entries from the DB for this title
					// this works if there are not multiple games with the same name
					stmt3.setInt(1, games.get(0).getGameId());
					stmt3.executeUpdate();
					
					System.out.println("Deleted junction table entries for book(s) <" + title + "> from DB");									
					
					// now delete entries in Books table for this title
					stmt4 = conn.prepareStatement(
							"delete from games " +
							"  where title = ? "
					);
					
					// delete the Game entries from the DB for this title
					stmt4.setString(1, title);
					stmt4.executeUpdate();
					
					System.out.println("Deleted book(s) with title <" + title + "> from DB");									
					
					// now check if the User(s) have any Books remaining in the DB
					// only need to check if there are any entries in junction table that have this author ID
					for (int i = 0; i < users.size(); i++) {
						// prepare to find Books for this User
						stmt5 = conn.prepareStatement(
								"select games.book_id from games, bookAuthors " +
								"  where bookAuthors.author_id = ? "
						);
						
						// retrieve any remaining games for this User
						stmt5.setInt(1, games.get(i).getGameId());
						resultSet5 = stmt5.executeQuery();						

						// if nothing returned, then delete User
						if (!resultSet5.next()) {
							stmt6 = conn.prepareStatement(
								"delete from users " +
								"  where author_id = ?"
							);
							
							// delete the User from DB
							stmt6.setInt(1, users.get(i).getUserId());
							stmt6.executeUpdate();
							
							System.out.println("Deleted author <" + users.get(i).getPassword() + ", " + users.get(i).getUsername() + "> from DB");
							
							// we're done with this, so close it, since we might have more to do
							DBUtil.closeQuietly(stmt6);
						}
						
						// we're done with this, so close it since we might have more to do
						DBUtil.closeQuietly(resultSet5);
						DBUtil.closeQuietly(stmt5);
					}
					return users;
				} finally {
					DBUtil.closeQuietly(resultSet1);
					DBUtil.closeQuietly(resultSet2);
					
					DBUtil.closeQuietly(stmt1);
					DBUtil.closeQuietly(stmt2);
					DBUtil.closeQuietly(stmt3);					
					DBUtil.closeQuietly(stmt4);					
				}
			}
		});
	}
	
	
	// wrapper SQL transaction function that calls actual transaction function (which has retries)
	public<ResultType> ResultType executeTransaction(Transaction<ResultType> txn) {
		try {
			return doExecuteTransaction(txn);
		} catch (SQLException e) {
			throw new PersistenceException("Transaction failed", e);
		}
	}
	
	// SQL transaction function which retries the transaction MAX_ATTEMPTS times before failing
	public<ResultType> ResultType doExecuteTransaction(Transaction<ResultType> txn) throws SQLException {
		Connection conn = connect();
		
		try {
			int numAttempts = 0;
			boolean success = false;
			ResultType result = null;
			
			while (!success && numAttempts < MAX_ATTEMPTS) {
				try {
					result = txn.execute(conn);
					conn.commit();
					success = true;
				} catch (SQLException e) {
					if (e.getSQLState() != null && e.getSQLState().equals("41000")) {
						// Deadlock: retry (unless max retry count has been reached)
						numAttempts++;
					} else {
						// Some other kind of SQLException
						throw e;
					}
				}
			}
			
			if (!success) {
				throw new SQLException("Transaction failed (too many retries)");
			}
			
			// Success!
			
			return result;
		} finally {
			DBUtil.closeQuietly(conn);
		}
	}

	// TODO: Here is where you name and specify the location of your Derby SQL database
	// TODO: Change it here and in SQLDemo.java under CS320_LibraryExample_Lab06->edu.ycp.cs320.sqldemo
	// TODO: DO NOT PUT THE DB IN THE SAME FOLDER AS YOUR PROJECT - that will cause conflicts later w/Git
	private Connection connect() throws SQLException {
		Connection conn = DriverManager.getConnection("jdbc:derby:Users/michaelhensel/Desktop/CS-320/Chess.db;create=true");		
		
		// Set autocommit() to false to allow the execution of
		// multiple queries/statements as part of the same transaction.
		conn.setAutoCommit(false);
		
		return conn;
	}
	
	// retrieves User information from query result set
	private void loadUser(User user, ResultSet resultSet, int index) throws SQLException {
		user.setUserId(resultSet.getInt(index++));
		user.setPassword(resultSet.getString(index++));
		user.setUsername(resultSet.getString(index++));
		user.setRank(resultSet.getInt(index++));
		user.setWins(resultSet.getInt(index++));
		user.setLosses(resultSet.getInt(index++));
		
	}
	
	// retrieves Game information from query result set
	private void loadGame(Game game, ResultSet resultSet, int index) throws SQLException {
		game.setGameId(resultSet.getInt(index++));
//		book.setAuthorId(resultSet.getInt(index++));  // no longer used
		game.setTurns(resultSet.getString(index++));
		game.setGameOver(false);
	}

private void loadPiece(Piece piece, ResultSet resultSet, int index) throws SQLException {
		piece.setColor(resultSet.getBoolean(index++));
		piece.setGameId(resultSet.getInt(index++));
		piece.setPosX(resultSet.getInt(index++));
		piece.setPosY(resultSet.getInt(index++));
		piece.setHasMoved(resultSet.getBoolean(index++));
		piece.setType(resultSet.getString(index++));
		piece.setCaptured(resultSet.getBoolean(index++));
	}
	//  creates the Authors and Books tables
	public void createTables() {
		executeTransaction(new Transaction<Boolean>() {
			@Override
			public Boolean execute(Connection conn) throws SQLException {
				PreparedStatement stmt1 = null;
				PreparedStatement stmt2 = null;
				PreparedStatement stmt3 = null;	
				PreparedStatement stmt4 = null;
			
				try {
					stmt1 = conn.prepareStatement(
							"create table users (" +
									"	user_id integer primary key " +
									"		generated always as identity (start with 1, increment by 1), " +									
									"	password varchar(40)," +
									"	username varchar(40)," +
									"	rank Integer," +
									"	wins Integer," +
									"	losses Integer" +
									")"
					);	
					stmt1.executeUpdate();
					
					System.out.println("Users table created");
					
					stmt2 = conn.prepareStatement(
							"create table games (" +
							"	game_id integer primary key " +
							"		generated always as identity (start with 1, increment by 1), " +
//							"	author_id integer constraint author_id references users, " +  	// this is now in the BookAuthors table
							"	turns varchar(70)," +
							"   gameOver boolean" +
							")"
							
							
					);
					stmt2.executeUpdate();
					
					System.out.println("Games table created");					
					
					stmt3 = conn.prepareStatement(
							"create table gameUsers (" +
							"	game_id   integer constraint game_id references games, " +
							"	user_id integer constraint user_id references users " +
							")"
					);
					stmt3.executeUpdate();
					
					System.out.println("gameUsers table created");
					
					stmt4 = conn.prepareStatement(
							"create table Pieces (" +
									"	color boolean, " +
									"	game_id Integer,	" +
									"	PosX Integer, " +
									"	PosY Integer, " +
									"	hasMoved boolean, " +
									"	type varchar(70), " +
									"	captured boolean" +
							")"
					);
					stmt4.executeUpdate();
					
					System.out.println("Pieces table created");	
										
					return true;
				} finally {
					DBUtil.closeQuietly(stmt1);
					DBUtil.closeQuietly(stmt2);
					DBUtil.closeQuietly(stmt3);
					DBUtil.closeQuietly(stmt4);
				}
			}
		});
	}
	
	// loads data retrieved from CSV files into DB tables in batch mode
	public void loadInitialData() {
		executeTransaction(new Transaction<Boolean>() {
			@Override
			public Boolean execute(Connection conn) throws SQLException {
				List<User> userList;
				List<Game> gameList;
				List<gameUser> gameUserList;
				List<Piece> PieceList;
				
				try {
					userList     = InitialData.getUsers();
					gameList       = InitialData.getGames();
					gameUserList = InitialData.getGameUsers();		
					PieceList = InitialData.getPieces();	
				} catch (IOException e) {
					throw new SQLException("Couldn't read initial data", e);
				}

				PreparedStatement insertUser     = null;
				PreparedStatement insertGame       = null;
				PreparedStatement insertGameUser = null;
				PreparedStatement insertPiece = null;

				try {
					// must completely populate Authors table before populating BookAuthors table because of primary keys
					insertUser = conn.prepareStatement("insert into users (password, username, rank, wins, losses) values (?, ?, ?, ?, ?)");
					for (User user : userList) {
//						insertAuthor.setInt(1, author.getAuthorId());	// auto-generated primary key, don't insert this
						insertUser.setString(1, user.getPassword());
						insertUser.setString(2, user.getUsername());
						insertUser.setInt(3, user.getRank());
						insertUser.setInt(4, user.getWins());
						insertUser.setInt(5,  user.getLosses());
						insertUser.addBatch();
					}
					insertUser.executeBatch();
					
					System.out.println("Users table populated");
					
					// must completely populate Books table before populating BookAuthors table because of primary keys
					insertGame = conn.prepareStatement("insert into games (turns, gameOver) values (?, ?)");
					for (Game game : gameList) {
//						insertBook.setInt(1, book.getBookId());		// auto-generated primary key, don't insert this
//						insertBook.setInt(1, book.getAuthorId());	// this is now in the BookAuthors table
						//insertBook.setInt(1, game.getGameId());
						insertGame.setString(1, game.getTurns());
						insertGame.setBoolean(2, game.getGameOver());
						insertGame.addBatch();
					}
					insertGame.executeBatch();
					
					System.out.println("Games table populated");					
					
					// must wait until all Books and all Authors are inserted into tables before creating gameUser table
					// since this table consists entirely of foreign keys, with constraints applied
					insertGameUser = conn.prepareStatement("insert into gameUsers (game_id, user_id) values (?, ?)");
					for (gameUser gameUser : gameUserList) {
						insertGameUser.setInt(1, gameUser.getGameId());
						insertGameUser.setInt(2, gameUser.getUserId());
						insertGameUser.addBatch();
					}
					insertGameUser.executeBatch();	
					
					System.out.println("GameUsers table populated");	
					
					insertPiece = conn.prepareStatement("insert into Pieces (color, game_id, PosX, PosY, hasMoved, type, captured ) values (?, ?, ?, ?, ?, ?, ?)");
					for (Piece piece : PieceList) {
						insertPiece.setBoolean(1, piece.getColor());
						insertPiece.setInt(2, piece.getGameId());
						insertPiece.setInt(3, piece.getPosX());
						insertPiece.setInt(4, piece.getPosY());
						insertPiece.setBoolean(5, piece.getHasMoved());
						insertPiece.setString(6, piece.getType());
						insertPiece.setBoolean(7, piece.getCaptured());
						insertPiece.addBatch();
					}
					insertPiece.executeBatch();	
					
					System.out.println("Pieces table populated");	
					
					return true;
				} finally {
					DBUtil.closeQuietly(insertGame);
					DBUtil.closeQuietly(insertUser);
					DBUtil.closeQuietly(insertGameUser);
					DBUtil.closeQuietly(insertPiece);
				}
			}
		});
	}
	
	// The main method creates the database tables and loads the initial data.
	public static void main(String[] args) throws IOException {
		System.out.println("Creating tables...");
		DerbyDatabase db = new DerbyDatabase();
		db.createTables();
		
		System.out.println("Loading initial data...");
		db.loadInitialData();
		
		System.out.println("Chess DB successfully initialized!");
	}


	@Override
	public Integer updateStatsByUser(String username, int newWin, int newLose) {
		return executeTransaction(new Transaction<Integer>() {
			@Override
			public Integer execute(Connection conn) throws SQLException {
				PreparedStatement stmt1 = null;
				PreparedStatement stmt2 = null;		
				
				ResultSet resultSet1 = null;
				ResultSet resultSet3 = null;				
				
				// for saving author ID and book ID
				Integer user_id = -1;

				// try to retrieve user_id (if it exists) from DB, for User's info passed into query
				try {
					stmt2 = conn.prepareStatement(
							"select * from users " +
							"where username = ?"
					);
					stmt2.setString(1, username);
					resultSet1 = stmt2.executeQuery();
					
					if (!resultSet1.next())
					{
						//user_id = resultSet1.getInt(1);
						System.out.println("User <" + username + "> does not exist");						
					}
					else {
						User user = new User();
						loadUser(user, resultSet1, 1);
						user_id = user.getUserId();
						if (newWin > user.getWins()) {
							user.setRank(user.calcRank(user.getRank(), true));
						} //works in practical sense where in an update onyl Win OR Loss is updated by 1, not both together
						else if (newLose > user.getLosses()) {
							user.setRank(user.calcRank(user.getRank(), false));
						}
						stmt1 = conn.prepareStatement(
								"update users " +
										"set wins = ?, losses = ?, rank = ?" +
										"where username = ?"
								);
						stmt1.setInt(1, newWin);
						stmt1.setInt(2, newLose);
						stmt1.setInt(3, user.getRank());
						stmt1.setString(4, username);
						
						// execute the query, get the result
						stmt1.executeUpdate();
						
						System.out.println("Stats updated for user: " + username);
					}

					
				} finally {
					DBUtil.closeQuietly(resultSet1);
					DBUtil.closeQuietly(stmt1);
					DBUtil.closeQuietly(stmt2);					
					DBUtil.closeQuietly(resultSet3);
				}
				return user_id;
			}
		});
	}


	@Override
	public List<User> findUserByUserByNameAndPass(String username, String password) {
		return executeTransaction(new Transaction<List<User>>() {
			@Override
			public List<User> execute(Connection conn) throws SQLException {
				PreparedStatement stmt = null;
				ResultSet resultSet = null;
				
				try {
					stmt = conn.prepareStatement(
							"select * from users " +
									"where username = ? and password = ?"
					);
					
					List<User> result = new ArrayList<User>();
					
					stmt.setString(1, username);
					stmt.setString(2, password);
					
					resultSet = stmt.executeQuery();
					
					// for testing that a result was returned
					Boolean found = false;
					
					while (resultSet.next()) {
						found = true;
						
						User user = new User();
						loadUser(user, resultSet, 1);
						
						result.add(user);
					}
					
					// check if any users were found
					if (!found) {
						System.out.println("No username with that password found");
					}
					
					return result;
				} finally {
					DBUtil.closeQuietly(resultSet);
					DBUtil.closeQuietly(stmt);
				}
			}
		});
	}


	public List<User> findUserbyUsername(String username) {
		return executeTransaction(new Transaction<List<User>>() {
			@Override
			public List<User> execute(Connection conn) throws SQLException {
				PreparedStatement stmt = null;
				ResultSet resultSet = null;
				
				try {
					stmt = conn.prepareStatement(
							"select * from users " +
									"where username = ?"
					);
					
					List<User> result = new ArrayList<User>();
					
					stmt.setString(1, username);
					
					resultSet = stmt.executeQuery();
					
					// for testing that a result was returned
					Boolean found = false;
					
					while (resultSet.next()) {
						found = true;
						
						User user = new User();
						loadUser(user, resultSet, 1);
						
						result.add(user);
					}
					
					// check if any users were found
					if (!found) {
						System.out.println("No user with that name found");
					}
					
					return result;
				} finally {
					DBUtil.closeQuietly(resultSet);
					DBUtil.closeQuietly(stmt);
				}
			}
		});
	}
}