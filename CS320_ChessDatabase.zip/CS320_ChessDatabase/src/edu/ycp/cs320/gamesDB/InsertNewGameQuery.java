package edu.ycp.cs320.gamesDB;


import java.util.Scanner;

import edu.ycp.cs320.gamesDB.persist.DatabaseProvider;
import edu.ycp.cs320.gamesDB.persist.IDatabase;

public class InsertNewGameQuery {
	public static void main(String[] args) throws Exception {
		Scanner keyboard = new Scanner(System.in);

		// Create the default IDatabase instance
		InitDatabase.init(keyboard);
		
		System.out.print("Enter user id: ");
		String username = keyboard.nextLine();
		int user_id = Integer.parseInt(username);
		
		
		// get the DB instance and execute the transaction
		IDatabase db = DatabaseProvider.getInstance();
		user_id = db.insertNewGame(user_id);

		// check if the insertion succeeded
		if (user_id > 0)
		{
			System.out.println("New Game successfully inserted");
		}
		else
		{
			System.out.println("Failed to insert new book (ID: " + user_id + ") into Books table: <" + username + ">");			
		}
	}
}