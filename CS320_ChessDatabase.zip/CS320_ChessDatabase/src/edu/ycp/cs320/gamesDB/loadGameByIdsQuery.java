package edu.ycp.cs320.gamesDB;

import java.util.List;
import java.util.Scanner;

import edu.ycp.cs320.gamesDB.model.Game;
import edu.ycp.cs320.gamesDB.model.Pair;
import edu.ycp.cs320.gamesDB.model.User;
import edu.ycp.cs320.gamesDB.persist.DatabaseProvider;
import edu.ycp.cs320.gamesDB.persist.IDatabase;

public class loadGameByIdsQuery {
	public static void main(String[] args) throws Exception {
		Scanner keyboard = new Scanner(System.in);

		// Create the default IDatabase instance
		InitDatabase.init(keyboard);
		
		System.out.print("Enter Game ID: ");
		String gameString = keyboard.nextLine();
		System.out.print("Enter User ID: ");
		String userString = keyboard.nextLine();
		System.out.print("Enter Opp ID: ");
		String oppString = keyboard.nextLine();
		
		int game_id = Integer.parseInt(gameString);
		int user_id = Integer.parseInt(gameString);
		int opp_id = Integer.parseInt(gameString);
		
		// get the DB instance and execute transaction
		IDatabase db = DatabaseProvider.getInstance();
		List<Game>gameList = db.loadGameByUserIDsAndGameId(user_id, opp_id, game_id);
		
		// check if anything was returned and output the list
		if (gameList.isEmpty()) {
			System.out.println("There are no games in the database");
		}
		else {
			for (Game game : gameList) {
				System.out.println(game.getGameId() + ", " + game.getTurns()+ ", " + game.getGameOver());
			}
		}
	}
}
